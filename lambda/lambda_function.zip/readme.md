# Curio Cards full set price generator

## [fullset.curio.cards](https://fullset.curio.cards)

Uses [NFTGo's api](https://docs.nftgo.io/reference/get_nfts_eth_v1_collection__contract_address__nfts_get-1). You can get a free api key by making an account with them.

Run with `NFTGO_API_KEY=your-api-key-here python generate.py`

## packaging for lambda

    pip install -r requirements.txt -t .

    zip -r lambda_function.zip .
